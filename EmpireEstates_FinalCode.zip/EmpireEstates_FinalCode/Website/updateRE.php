<?php
ini_set('error_reporting', E_ALL);
ini_set('display_errors', 1);
session_start();
$reid = $_GET['reid'];

$conn = mysqli_connect("localhost", "CityRealty", "QKSH7XJws7MCpxWR", "CityRealty");
mysqli_query($conn,"SET NAMES utf8");

if (!$conn) {
	die("Connection failed: " . mysqli_connect_error());
}
if(isset($_POST['next']))
{
	$category = $_POST['category'];
	
	/*real estate*/
	$astreet = $_POST['astreet'];
	$acity = $_POST['acity']; 
	$region = $_POST['region'];
	$zone = $_POST['zone'];
	$area_tm = $_POST['area_tm'];
	$realestate_status = $_POST['realestate_status'];
	$legal_control = $_POST['legal_control'];
	$RegistrationTitleNo = $_POST['RegistrationTitleNo'];
	$ArithmosFilSxed = $_POST['ArithmosFilSxed'];
	$currency = $_POST['currency'];
	$vat = $_POST['vat'];
	$RegistartionTitle = $_POST['RegistartionTitle'];
	$AgentUsername= $_POST['AgentUsername'];
	$OrderCode = $_POST['OrderCode'];
	$TypeCode = $_POST['TypeCode'];
	$OrderStart = $_POST['OrderStart'];
	$OrderStop = $_POST['OrderStop'];
	$AgentRewardPercentage= $_POST['AgentRewardPercentage'];
	$AgentReward= $_POST['AgentReward'];	
	$available_from = $_POST['AvailableFrom'];
	$transfer_cost= $_POST['TransferCost'];
	$transfer_vat= $_POST['TransferVAT'];
	$astreet_no = $_POST['astreet_no'];
	$acountry = $_POST['acountry'];
	$apostal_code = $_POST['apostal_code'];
	$Latitude = $_POST['Latitude'];
	$Longitude = $_POST['Longitude'];
	$purpose = $_POST['purpose'];
	$piece_no = $_POST['piece_no'];
	$folder_no = $_POST['folder_no'];
	$ArithmosAdOik = $_POST['ArithmosAdOik'];
	$price = $_POST['price'];
	$MortgageLoan = $_POST['ipothiki'];
	$notes= $_POST['notes'];
	$short_desc = $_POST['short_desc'];
	$desc = $_POST['desc'];
	$consideration_exchange= $_POST['ConsiderationExchange'];


	$sql = "UPDATE RealEstate SET AStreet='$astreet',Acity='$acity',ARegionCode='$region',Zone='$zone',AreaTM='$area_tm',RealEstateStatus='$realestate_status',LegalControl='$legal_control',RegistrationTitleNo='$RegistrationTitleNo',ArithmosFilSxed='$ArithmosFilSxed',Currency='$currency',VAT='$vat',RegistrationTitle='$RegistartionTitle',AgentUsername='$AgentUsername',OrderCode='$OrderCode', TypeOrder='$TypeCode',OrderStart='$OrderStart',OrderStop='$OrderStop',AgentRewardPercentage='$AgentRewardPercentage',AgentReward='$AgentReward',AvailableFrom='$available_from',TransferCost='$transfer_cost', TransferVAT='$transfer_vat',AStreetNo='$astreet_no',ACountry='$acountry',APostalCode='$apostal_code',Latitude='$Latitude',Longitude='$Longitude',RegistrationPurpose='$purpose',PieceNo='$piece_no',FolderNo='$folder_no',ArithmosAdOik='$ArithmosAdOik',Price='$price',MortgageLoan='$MortgageLoan',Notes='$notes',ShortDescription='$short_desc',Description='$desc',ConsiderationExchange='$consideration_exchange',Category='$category' WHERE RealEstateNo=$reid";

	$result = mysqli_query($conn,$sql)
	or die("Error: !".mysqli_error($conn));
	mysqli_close($conn);
	if ($category=="Ξενοδοχείο")
		header("Location: updateHotel.php?reid=$reid&category=$category");
	else if ($category=="Επαγγελματικός χώρος")
		header("Location: updateOffice.php?reid=$reid&category=$category");
	else if ($category=="Γη")
		header("Location: updateLand.php?reid=$reid&category=$category");
	else if ($category=="Κατοικία")
		header("Location: updateRecident.php?reid=$reid&category=$category");
}
?>



