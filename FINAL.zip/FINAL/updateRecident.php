<?php session_start(); 
$conn = mysqli_connect("localhost", "CityRealty", "QKSH7XJws7MCpxWR", "CityRealty");
if (!$conn) {
	die("Connection failed: " . mysqli_connect_error());
}
mysqli_query($conn,"SET NAMES utf8");
$category = $_GET['category'];
$reid = $_GET['reid'];
$sql = "SELECT * FROM Building WHERE RealEstateNo=$reid";
$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_assoc($result);
$sql2 = "SELECT * FROM Residence WHERE RealEstateNo=$reid";
$result2 = mysqli_query($conn, $sql2);
$row2 = mysqli_fetch_assoc($result2);
?>
<!DOCTYPE html>
<html lang="en">

<head>

	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="">
	<meta name="author" content="">

	<title>Edit Property</title>

	<!-- Bootstrap Core CSS -->
	<link href="css/bootstrap.min.css" rel="stylesheet">

	<!-- Custom CSS -->
	<link href="css/sb-admin.css" rel="stylesheet">

	<!-- Custom Fonts -->
	<link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

	<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->

	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>

	<!--Navbar style-->
	<style type="text/css">
		#menu {
			overflow: hidden;
		}
		#menu li {
			display: block;
			position: relative;
			float: left;
		}
		#menu li:first-child {
			margin-left: 0px;
			border-bottom: solid #000000
		}
		#menu li:last-child {
			margin-left: 100px;
		}
		#menu li a {
			display: block;
			color: #333;
			font-size: 18px;
			text-align: center;
			text-decoration: none;
			text-transform: uppercase;
		}
		#menu li span {
			display: none;
		}
		#menu li.active span {
			display: block;
			position: absolute;
			width: 100%;
			text-align: center;
		}
		#menu li.active a {
			background-color: #c03e62;
			outline: #FFF;
			outline-style: dashed;
			color: #CCC;
			text-decoration: none;
		}
		#menu li a:hover {
			text-decoration: none;
			background-image: none;
			background-color: #c03e62;
			outline: #FFF;
		}
	</style>

	<!--Dropdown style-->
	<style>
		.dropdown-content {
			list-style: none;
			display: none;
			position: absolute;
			background-color: #f9f9f9;
			min-width: 160px;
			box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
		}
		.dropdown-content a {
			color: #337ab7;
			padding: 12px 16px;
			text-decoration: none;
			display: block;
			text-align: left;
		}
		.dropdown-content a:hover {
			background-color: #f1f1f1
		}
		.dropdown:hover .dropdown-content {
			display: block;
		}

		#content #mainwrap #tabs .column.col3 #title2 #title3 #title4 h2 {
			font-family: Arial, Helvetica, sans-serif;
			font-size: 26em;
			font-style: normal;
			line-height: normal;
			font-weight: bold;
			font-variant: normal;
		}
		#content #mainwrap #RealEstateTab .column.col3 #title2 h2 {
			font-size: large;
			font-style: normal;
			line-height: normal;
			font-weight: bold;
			font-variant: normal;
			text-decoration: underline;
		}
		#content #mainwrap #RealEstateTab {
			border: 5px solid black;
			border-style: solid;
			background: #FFFFFF;
		}
		#content #mainwrap #tabs {
			border: 5px solid black;
			border-style: solid;
			background: #FFFFFF;
		}
		.fieldGroup {
			color: #c03e62;
		}
		.field {
			color: #000000;
			width: 30%;
		}
		.value {
			color: #333333;
			text-decoration: none;
		}
		table {
			border: 0px solid black;
			padding: 5px;
			text-align: left;
			width: 100%;
		}
		th, td {
			border: 0px solid black;
			padding: 3px;
			text-align: left;
		}

		#content #mainwrap #menu {
			padding: 20px;
			overflow: hidden;
		}
		#mainwrap {
			overflow: hidden;
			position: relative;
			margin: 0 auto;
		}
		#content {
			overflow: hidden;
			position: relative;
		}

		#pagecontainer {
			position: relative;
			width: 9999px;
		}

		.section {
			float: left;
			position: relative;
			width: 100%;
			padding: 30px;
			overflow: hidden;
		}

		#RealEstateTab #tabs {
			overflow-y: scroll;
		}

		#tabs {
			display: none;
		}

		.section_title {
			color: #c03e62;
			text-shadow: 1px 1px 1px #000000;
		}

		.note {
			bottom: 20px;
			width: 95%;
			padding-left: 50px;
			padding-top: 1000px;
		}
	</style>

</head>

<body>

	<div id="wrapper">

		<!-- Navigation -->
		<nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
			<!-- Brand and toggle get grouped for better mobile display -->
			<div class="navbar-header">
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<a class="navbar-brand" href="#">Αλλαγή στοιχείων ακινήτου</a>
			</div>
			<!-- Top Menu Items -->
			<ul class="nav navbar-right top-nav">
				<li class="dropdown">
					<a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-user"></i> <?php echo $_SESSION['id']; ?>
						<b class="caret"></b></a>
						<ul class="dropdown-menu">
							<li>
								<a href="profile_broker.php"><i class="fa fa-fw fa-user"></i> Profile</a>
							</li>
							<li class="divider"></li>
							<li>
								<a href="logout_inc.php"><i class="fa fa-fw fa-power-off"></i> Log Out</a>
							</li>
						</ul>
					</li>
				</ul>
				<!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
				<div class="collapse navbar-collapse navbar-ex1-collapse">
					<ul class="nav navbar-nav side-nav">
						<li>
							<a href="broker_manage.php"><i class="fa fa-fw fa-edit"></i>Διαχείριση Ακινήτων</a>

						</li>
						<li>
							<a target="_blank" href="http://accounts.google.com/AccountChooser?continue=https%3A%2F%2Fcalendar.google.com%2Fcalendar%2Frender%3Fpli%3D1&hl=en&service=cl&scc=1"><i class="fa fa-fw fa-calendar"></i>Ημερολόγιο</a>
						</li>

					</ul>
				</div>
				<!-- /.navbar-collapse -->
			</nav>

			<div id="page-wrapper">

				<div class="container-fluid">

					<!-- Page Heading -->
					<div class="row">
						<div class="col-lg-12">
							<h1 class="page-header">Αλλαγή στοιχείων ακινήτου</h1>
						</div>
					</div>
					<!-- /.row -->

					<div class="row">
						
						<!-- Start of section : TABS (content) -->
						<div style="clear:both"></div>
						<div id="content">
							<div id="mainwrap">
								<!-- Real Estate details -->
								<div>
									<h3 id="title" class="section_title"> Λεπτομέρειες και Χαρακτηριστικά </h3>
								</div>

								<!-- Start of first "tab" -->
								<div style="clear:both"></div>
								<div id="RealEstateTab" class="section">
									<?php echo "<form role='form' id='form1' action='updateRE2.php?reid=".$reid."&category=".$category."' method='post'>"; ?>

									<div id="katoikia"><!--start of katoikia-->
										<div class="col-md-6"><!--1i stili-->
											<label>Τύπος Κατοικίας</label>
											<span runat="server" ID="required" style="color:Red;" visible="false"> *</span>
											<select name="ResidenceType" id="ResidenceType" required class="form-control">
												<?php echo "<option value='Ανεξάρτητη κατοικία'";
												if ($row2['ResidenceType']=="Ανεξάρτητη κατοικία")
													echo " selected='selected'";
												echo ">Ανεξάρτητη κατοικία</option>
												<option value='Μεζονέτα'";
												if ($row2['ResidenceType']=="Μεζονέτα")
													echo " selected='selected'";
												echo ">Μεζονέτα</option>
												<option value='Διαμέρισμα'";
												if ($row2['ResidenceType']=="Διαμέρισμα")
													echo " selected='selected'";
												echo ">Διαμέρισμα</option>
												<option value='Ρετιρέ'";
												if ($row2['ResidenceType']=="Ρετιρέ")
													echo " selected='selected'";
												echo ">Ρετιρέ</option>
												<option value='Άλλο'";
												if ($row2['ResidenceType']=="Άλλο")
													echo " selected='selected'";
												echo ">Άλλο</option>";
												?>
											</select>
											<div class="col-md-6">
												<br><label>Αριθμός Κουζίνων</label>
												<span runat="server" ID="required" style="color:Red;" visible="false"> *</span>
												<input type="text" class="form-control" required value="<?php echo $row2['Kitchen']; ?>" name="Kitchen">
												<br>
											</div>
											<div class="col-md-6">
												<br><label>Αριθμός Μπάνιων</label>
												<span runat="server" ID="required" style="color:Red;" visible="false"> *</span>
												<input type="text" class="form-control" required value="<?php echo $row2['Bathrooms']; ?>" name="Bathrooms">
												<br>
											</div>

											<br><label>Εμβαδόν Ταράτσας Ιδιοκτήτη (τ.μ.)</label>
											<input type="text" class="form-control" value="<?php echo $row2['RooftopArea']; ?>" name="RooftopArea">
											<br>

										</div><!--end of 1i stili-->

										<div class="col-md-6"><!--2i stili-->
											<div class="col-md-6">
												<label>Αριθμός Υπνοδωματίων</label>
												<span runat="server" ID="required" style="color:Red;" visible="false"> *</span>
												<input type="text" class="form-control" required value="<?php echo $row2['TotalBedrooms']; ?>" name="TotalBedrooms">
											</div>
											<div class="col-md-6">
												<label>Αριθμός master Υπνοδωματίων</label>
												<span runat="server" ID="required" style="color:Red;" visible="false"> *</span>
												<input type="text" class="form-control" required value="<?php echo $row2['MasterBedroom']; ?>" name="MasterBedroom">
											</div>

											<div class="col-md-6">
												<br><label>Αριθμός Σαλονιών</label>
												<span runat="server" ID="required" style="color:Red;" visible="false"> *</span>
												<input type="text" class="form-control" required value="<?php echo $row2['LivingRooms']; ?>" name="LivingRooms">
												<br>
											</div>
											<div class="col-md-6">
												<br><label>Εμβαδόν Μπαλκονιών(τ.μ.)</label>
												<span runat="server" ID="required" style="color:Red;" visible="false"> *</span>
												<input type="text" class="form-control" required value="<?php echo $row2['BalconyArea']; ?>" name="BalconyArea">
												<br>
											</div>
											<label>Επιπλωμένο</label>
											<span runat="server" ID="required" style="color:Red;" visible="false"> *</span>
											<select name="Furnished" id="Furnished" required class="form-control">
												<?php
												echo"<option value='1'";
												if ($row2['Furnished']=="1")
													echo " selected='selected'";
												echo ">Yes</option>
												<option value='0'";
												if ($row2['Furnished']=="0")
													echo " selected='selected'";
												echo ">No</option>";
												?>
											</select>
											<br>

										</div><!--end of 2i stili-->
									</div> <!--end of katoikia-->
									
									<div id="ksenodoxeio">
										<div class="col-md-6"><!--1i stili-->
											<label>Τύπος Κτηρίου</label>
											<span runat="server" ID="required" style="color:Red;" visible="false"> *</span>
											<select name="BuildingType" id="BuildingType" required class="form-control">
												<?php echo "<option value='Κατοικία'";
												if ($row['BuildingType']=="Κατοικία")
													echo " selected='selected'";
												echo ">Κατοικία</option>
												<option value='Επαγγελματικός χώρος'";
												if ($row['BuildingType']=="Επαγγελματικός χώρος")
													echo " selected='selected'";
												echo ">Επαγγελματικός χώρος</option>
												<option value='Ξενοδοχείο'";
												if ($row['BuildingType']=="Ξενοδοχείο")
													echo " selected='selected'";
												echo ">Ξενοδοχείο</option>
												<option value='Άλλο'";
												if ($row['BuildingType']=="Άλλο")
													echo " selected='selected'";
												echo ">Άλλο</option>";
												?>
											</select>
											<div class="col-md-6">
												<br><label>Έτος Κατασκευής</label>
												<span runat="server" ID="required" style="color:Red;" visible="false"> *</span>
												<input type="text" class="form-control" required value="<?php echo $row['ConstructionYear']; ?>" name="ConstructionYear">
											</div>
											<div class="col-md-6">
												<br><label>Αριθμός Ορόφων</label>
												<span runat="server" ID="required" style="color:Red;" visible="false"> *</span>
												<input type="text" class="form-control" required value="<?php echo $row['NumOfFloors']; ?>" name="NumOfFloorsB">
											</div>

											<div class="col-md-6">
												<br><label>Αριθμός από Παρκινγκ</label>
												<span runat="server" ID="required" style="color:Red;" visible="false"> *</span>
												<input type="text" class="form-control" required value="<?php echo $row['ParkingSpots']; ?>" name="ParkingSpots">
											</div>
											<div class="col-md-6">
												<br><label>Αριθμός Δωματίων</label>
												<span runat="server" ID="required" style="color:Red;" visible="false"> *</span>
												<input type="text" class="form-control" required value="<?php echo $row['NumOfRooms']; ?>" name="NumOfRooms">
											</div>	

											<div class="col-md-6">
												<br><label>Ενεργειακό Πιστοποιητικό</label>
												<span runat="server" ID="required" style="color:Red;" visible="false"> *</span>
												<select name="EnergyCertificate" id="EnergyCertificate" required class="form-control">
													<?php echo "<option value='Class A'";
													if ($row['EnergyCertificate']=="Class A")
														echo " selected='selected'";
													echo ">Class A</option>
													<option value='Class B'";
													if ($row['EnergyCertificate']=="Class B")
														echo " selected='selected'";
													echo ">Class B</option>
													<option value='Class C'";
													if ($row['EnergyCertificate']=="Class C")
														echo " selected='selected'";
													echo ">Class C</option>
													<option value='Class D'";
													if ($row['EnergyCertificate']=="Class D")
														echo " selected='selected'";
													echo ">Class D</option>
													<option value='Unknown'";
													if ($row['EnergyCertificate']=="Unknown")
														echo " selected='selected'";
													echo ">Unknown</option>";
													?>
												</select><br>
											</div>
											<div class="col-md-6">
												<br><label>Αριθμός Επιπέδων</label>
												<span runat="server" ID="required" style="color:Red;" visible="false"> *</span>
												<select name="Levels" id="Levels" required class="form-control">
													<?php echo"<option value='1'";
													if ($row['Levels']=="1")
														echo " selected='selected'";
													echo ">1</option>
													<option value='2'";
													if ($row['Levels']=="2")
														echo " selected='selected'";
													echo ">2</option>
													<option value='3'";
													if ($row['Levels']=="3")
														echo " selected='selected'";
													echo ">3</option>
													<option value='4'";
													if ($row['Levels']=="4")
														echo " selected='selected'";
													echo ">4</option>
													<option value='5'";
													if ($row['Levels']=="5")
														echo " selected='selected'";
													echo ">5</option>";
													?>
												</select><br>
											</div>
										</div><!--end of 1i stili-->

										<div class="col-md-6"><!--2i stili-->
											<div class="col-md-6">
												<label>Ανακαινισμένο</label>
												<span runat="server" ID="required" style="color:Red;" visible="false"> *</span>
												<select name="Renovated" id="Renovated" required class="form-control">
													<?php
													echo"<option value='1'";
													if ($row['Renovated']=="1")
														echo " selected='selected'";
													echo ">Yes</option>
													<option value='0'";
													if ($row['Renovated']=="0")
														echo " selected='selected'";
													echo ">No</option>";
													?>
												</select>
												<br>
											</div>
											<div class="col-md-6">
												<label>Έτος Ανακαίνισης</label>
												<input type="text" class="form-control" value="<?php echo $row['RenovationYear']; ?>" name="RenovationYear">
												<br>
											</div>	

											<div class="col-md-6">
												<label>Αριθμός WC</label>
												<span runat="server" ID="required" style="color:Red;" visible="false"> *</span>
												<input type="text" class="form-control" required value="<?php echo $row['NumOfWC']; ?>" name="NumOfWC">
												<br>
											</div>
											<div class="col-md-6">
												<label>Αποχέτευση</label>
												<span runat="server" ID="required" style="color:Red;" visible="false"> *</span>
												<select name="Drainage" id="Drainage" required class="form-control">
													<?php
													echo"<option value='1'";
													if ($row['Drainage']=="1")
														echo " selected='selected'";
													echo ">Yes</option>
													<option value='0'";
													if ($row['Drainage']=="0")
														echo " selected='selected'";
													echo ">No</option>";
													?>
												</select>
												<br>
											</div>

											<div class="col-md-6">
												<label>Τύπος Θέρμανσης</label>
												<span runat="server" ID="required" style="color:Red;" visible="false"> *</span>
												<select name="HeatingFuel" id="HeatingFuel" required class="form-control">
													<?php echo"<option value='Πετρέλαιο'";
													if ($row['HeatingFuel']=="Πετρέλαιο")
														echo " selected='selected'";
													echo ">Πετρέλαιο</option>
													<option value='Γκάζι'";
													if ($row['HeatingFuel']=="Γκάζι")
														echo " selected='selected'";
													echo ">Γκάζι</option>
													<option value='Ηλεκτρική'";
													if ($row['HeatingFuel']=="Ηλεκτρική")
														echo " selected='selected'";
													echo ">Ηλεκτρική</option>
													<option value='Τζάκι'";
													if ($row['HeatingFuel']=="Τζάκι")
														echo " selected='selected'";
													echo ">Τζάκι</option>
													<option value='Κλιματισμός'";
													if ($row['HeatingFuel']=="Κλιματισμός")
														echo " selected='selected'";
													echo ">Κλιματισμός</option>
													<option value='Άλλο'";
													if ($row['HeatingFuel']=="Άλλο")
														echo " selected='selected'";
													echo ">Άλλο</option>";
													?>
												</select>
												<br>
											</div>
											<div class="col-md-6">
												<label>Μέσο Θέρμανσης</label>
												<span runat="server" ID="required" style="color:Red;" visible="false"> *</span>
												<select name="HeatingType" id="HeatingType" required class="form-control">
													<?php echo "<option value='Κεντρική'";
													if ($row['HeatingType']=="Κεντρική")
														echo " selected='selected'";
													echo ">Κεντρική</option>
													<option value='Ανεξάρτητη'";
													if ($row['HeatingType']=="Ανεξάρτητη")
														echo " selected='selected'";
													echo ">Ανεξάρτητη</option>
													<option value='Κοινόχρηστη'";
													if ($row['HeatingType']=="Κοινόχρηστη")
														echo " selected='selected'";
													echo ">Κοινόχρηστη</option>
													<option value='Άλλο'";
													if ($row['HeatingType']=="Άλλο")
														echo " selected='selected'";
													echo ">Άλλο</option>";
													?>
												</select>
												<br>
											</div>
											<div class="col-md-6">
												<label>Μηνιαία κοινόχρηστα</label>
												<span runat="server" ID="required" style="color:Red;" visible="false"> *</span>
												<input type="text" class="form-control" required value="<?php echo $row['AvgSharedCosts']; ?>" name="AvgSharedCosts">
												<br>
											</div>
											<div class="col-md-6">
												<label>Υπό Κατασκευή</label>
												<span runat="server" ID="required" style="color:Red;" visible="false"> *</span>
												<select name="UnderConstruction" id="UnderConstruction" required class="form-control">
													<?php
													echo"<option value='1'";
													if ($row['UnderConstruction']=="1")
														echo " selected='selected'";
													echo ">Yes</option>
													<option value='0'";
													if ($row['UnderConstruction']=="0")
														echo " selected='selected'";
													echo ">No</option>";
													?>
												</select>
												<br>
											</div>
										</div><!--end of 2i stili-->

									</div><!--end of ksenodoxeio-->


									<br>
									<br>
									<br>

									<div style="float:right;">
										<button type="submit" name="send" class="btn btn-success">
											Καταχώρηση Ακινήτου
										</button>
									</div>
								</form>
							</div>

							<!-- End of first "tab" -->

						</div>
						<!-- /.main wrap -->
					</div>
					<!-- /. End of section : TABS (content) -->

				</div>
				<!-- /.row -->

			</div>
			<!-- /.container-fluid -->

		</div>
		<!-- /#page-wrapper -->

	</div>
	<!-- /#wrapper -->

	<!-- jQuery -->
	<script src="js/jquery.js"></script>

	<!-- Bootstrap Core JavaScript -->
	<script src="js/bootstrap.min.js"></script>

</body>

</html>