<?php 
session_start(); 
$conn = mysqli_connect("localhost", "CityRealty", "QKSH7XJws7MCpxWR", "CityRealty");
if (!$conn) {
	die("Connection failed: " . mysqli_connect_error());
}
mysqli_query($conn,"SET NAMES utf8");
$reid = $_GET['reid'];
$sql = "SELECT * FROM RealEstate WHERE RealEstateNo=$reid";
$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_assoc($result);
?>
<!DOCTYPE html>
<html lang="en">

<head>

	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="">
	<meta name="author" content="">

	<title>Edit Property</title>

	<!-- Bootstrap Core CSS -->
	<link href="css/bootstrap.min.css" rel="stylesheet">

	<!-- Custom CSS -->
	<link href="css/sb-admin.css" rel="stylesheet">

	<!-- Custom Fonts -->
	<link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

	<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->

	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>

	<!--Navbar style-->
	<style type="text/css">
		#menu {
			overflow: hidden;
		}
		#menu li {
			display: block;
			position: relative;
			float: left;
		}
		#menu li:first-child {
			margin-left: 0px;
			border-bottom: solid #000000
		}
		#menu li:last-child {
			margin-left: 100px;
		}
		#menu li a {
			display: block;
			color: #333;
			font-size: 18px;
			text-align: center;
			text-decoration: none;
			text-transform: uppercase;
		}
		#menu li span {
			display: none;
		}
		#menu li.active span {
			display: block;
			position: absolute;
			width: 100%;
			text-align: center;
		}
		#menu li.active a {
			background-color: #c03e62;
			outline: #FFF;
			outline-style: dashed;
			color: #CCC;
			text-decoration: none;
		}
		#menu li a:hover {
			text-decoration: none;
			background-image: none;
			background-color: #c03e62;
			outline: #FFF;
		}
	</style>

	<!--Dropdown style-->
	<style>
		.dropdown-content {
			list-style: none;
			display: none;
			position: absolute;
			background-color: #f9f9f9;
			min-width: 160px;
			box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
		}
		.dropdown-content a {
			color: #337ab7;
			padding: 12px 16px;
			text-decoration: none;
			display: block;
			text-align: left;
		}
		.dropdown-content a:hover {
			background-color: #f1f1f1
		}
		.dropdown:hover .dropdown-content {
			display: block;
		}

		#content #mainwrap #tabs .column.col3 #title2 #title3 #title4 h2 {
			font-family: Arial, Helvetica, sans-serif;
			font-size: 26em;
			font-style: normal;
			line-height: normal;
			font-weight: bold;
			font-variant: normal;
		}
		#content #mainwrap #RealEstateTab .column.col3 #title2 h2 {
			font-size: large;
			font-style: normal;
			line-height: normal;
			font-weight: bold;
			font-variant: normal;
			text-decoration: underline;
		}
		#content #mainwrap #RealEstateTab {
			border: 5px solid black;
			border-style: solid;
			background: #FFFFFF;
		}
		#content #mainwrap #tabs {
			border: 5px solid black;
			border-style: solid;
			background: #FFFFFF;
		}
		.fieldGroup {
			color: #c03e62;
		}
		.field {
			color: #000000;
			width: 30%;
		}
		.value {
			color: #333333;
			text-decoration: none;
		}
		table {
			border: 0px solid black;
			padding: 5px;
			text-align: left;
			width: 100%;
		}
		th, td {
			border: 0px solid black;
			padding: 3px;
			text-align: left;
		}

		#content #mainwrap #menu {
			padding: 20px;
			overflow: hidden;
		}
		#mainwrap {
			overflow: hidden;
			position: relative;
			margin: 0 auto;
		}
		#content {
			overflow: hidden;
			position: relative;
		}

		#pagecontainer {
			position: relative;
			width: 9999px;
		}

		.section {
			float: left;
			position: relative;
			width: 100%;
			padding: 30px;
			overflow: hidden;
		}

		#RealEstateTab #tabs {
			overflow-y: scroll;
		}

		#tabs {
			display: none;
		}

		.section_title {
			color: #c03e62;
			text-shadow: 1px 1px 1px #000000;
		}

		.note {
			bottom: 20px;
			width: 95%;
			padding-left: 50px;
			padding-top: 1000px;
		}
	</style>

	<script>
		function showtemplate(temp) {
			$.ajax({
				type : "POST",
				url : 'showLocations2.php',
				data : {
					'section' : temp
				},
				success : function(data) {
					$("#somewhere").html(data);
				}
			});
		}
	</script>

</head>

<body>

	<div id="wrapper">

		<!-- Navigation -->
		<nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
			<!-- Brand and toggle get grouped for better mobile display -->
			<div class="navbar-header">
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<a class="navbar-brand" href="#">Αλλαγή στοιχείων ακινήτου</a>
			</div>
			<!-- Top Menu Items -->
			<ul class="nav navbar-right top-nav">
				<li class="dropdown">
					<a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-user"></i> <?php echo $_SESSION['id']; ?>
						<b class="caret"></b></a>
						<ul class="dropdown-menu">
							<li>
								<a href="profile_admin.php"><i class="fa fa-fw fa-user"></i> Profile</a>
							</li>
							<li class="divider"></li>
							<li>
								<a href="logout_inc.php"><i class="fa fa-fw fa-power-off"></i> Log Out</a>
							</li>
						</ul>
					</li>
				</ul>
				<!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
				<div class="collapse navbar-collapse navbar-ex1-collapse">
					<ul class="nav navbar-nav side-nav">
						<li>
							<a href="admin.php"><i class="fa fa-fw fa-edit"></i>Διαχείριση Ακινήτων</a>

						</li>
						<li>
							<a target="_blank" href="http://accounts.google.com/AccountChooser?continue=https%3A%2F%2Fcalendar.google.com%2Fcalendar%2Frender%3Fpli%3D1&hl=en&service=cl&scc=1"><i class="fa fa-fw fa-calendar"></i>Ημερολόγιο</a>
						</li>
						<li>
							<a href="newBroker.php"><i class="fa fa-users"></i> Νέος Μεσίτης</a>
						</li>

					</ul>
				</div>
				<!-- /.navbar-collapse -->
			</nav>

			<div id="page-wrapper">

				<div class="container-fluid">

					<!-- Page Heading -->
					<div class="row">
						<div class="col-lg-12">
							<h1 class="page-header">Αλλαγή στοιχείων ακινήτου</h1>
						</div>
					</div>
					<!-- /.row -->

					<div class="row">
						<form role="form" id="form1" action="updateRE.php?reid=<?php echo $reid; ?>" method="post">
							<div class="form-group">
								<h3 class="section_title">Κατηγορία *</h3>
								<select name="category" class="form-control" id="category" >
									<?php 
									echo"<option value='Γη'";
									if ($row['Category']=="Γη")
										echo " selected='selected'";
									echo">Γη</option>
									<option value='Κατοικία'";
									if ($row['Category']=="Κατοικία")
										echo " selected='selected'";
									echo">Κατοικία</option>
									<option value='Επαγγελματικός χώρος'";
									if ($row['Category']=="Επαγγελματικός χώρος")
										echo " selected='selected'";
									echo ">Επαγγελματικός χώρος</option>
									<option value='Ξενοδοχείο'";
									if ($row['Category']=="Ξενοδοχείο")
										echo " selected='selected'";
									echo ">Ξενοδοχείο</option>";
									?>
								</select>
							</div>

							<!-- Start of section : TABS (content) -->
							<div style="clear:both"></div>
							<div id="content">
								<div id="mainwrap">
									<!-- Real Estate details -->
									<div>
										<h3 id="title" class="section_title"> Βασικές Πληροφορίες </h3>
									</div>

									<!-- Start of first "tab" -->
									<div style="clear:both"></div>
									<div id="RealEstateTab" class="section">
										<div class="form-group">
											<br>
											<label>Πόλη/Περιοχή:</label>
											<span runat="server" ID="required" style="color:Red;" visible="false"> *</span>
											<select name="acity" id="acity" required class="form-control" onchange="showtemplate(this.value)">
												<?php 
												echo"<option value='Λευκωσία'";
												if ($row['ACity']=="Λευκωσία")
													echo " selected='selected'";
												echo">Λευκωσία</option>
												<option value='Λεμεσός'";
												if ($row['ACity']=="Λεμεσός")
													echo " selected='selected'";
												echo ">Λεμεσός</option>
												<option value='Λάρνακα'";
												if ($row['ACity']=="Λάρνακα")
													echo " selected='selected'";
												echo ">Λάρνακα</option>
												<option value='Πάφος'";
												if ($row['ACity']=="Πάφος")
													echo " selected='selected'";
												echo ">Πάφος</option>
												<option value='Αμμόχωστος'";
												if ($row['ACity']=="Αμμόχωστος")
													echo " selected='selected'";
												echo">Αμμόχωστος</option>";
												?>
											</select>
										</div>
										<div class="row containerwithcheckboxes form-group" id="somewhere"></div>
										<div class="col-md-6">
											<label>Διεύθυνση</label>
											<span runat="server" ID="required" style="color:Red;" visible="false"> *</span>
											<input type="text" class="form-control" required name="astreet" value="<?php echo $row['AStreet']; ?>">
											<br />
											<label>Ζώνη</label>
											<input type="text" class="form-control" name="zone" value="<?php echo $row['Zone']; ?>">
											<br>
											<label>Εμβαδόν (τ.μ.)</label>
											<span runat="server" ID="required" style="color:Red;" visible="false"> *</span>
											<input type="text" class="form-control"required  name="area_tm" value="<?php echo $row['AreaTM']; ?>">
											<div class="col-md-6">
												<br>
												<label>Κατάσταση Ακινήτου</label>
												<input type="text" class="form-control" name="realestate_status" value="<?php echo $row['RealEstateStatus']; ?>">
											</div>
											<div class="col-md-6">
												<br>
												<label>Νομικός έλεγχος</label>
												<span runat="server" ID="required" style="color:Red;" visible="false"> *</span>
												<select name="legal_control" id="legal_control" required class="form-control">
													<?php
													echo"<option value='1'";
													if ($row['LegalControl']=="1")
														echo " selected='selected'";
													echo ">Yes</option>
													<option value='0'";
													if ($row['LegalControl']=="0")
														echo " selected='selected'";
													echo ">No</option>";
													?>
												</select>
											</div>
											<div class="col-md-6">
												<br>
												<label>Αριθμός τίτλου εγγρ.</label>
												<input type="text" class="form-control" name="RegistrationTitleNo"
												value="<?php echo $row['RegistrationTitleNo']; ?>">
											</div>
											<div class="col-md-6">
												<br>
												<label>Αριθμός φυλ. σχεδ.</label>
												<input type="text" class="form-control" name="ArithmosFilSxed"
												value="<?php echo $row['ArithmosFilSxed']; ?>">
											</div>
											<div class="col-md-6">
												<div class="form-group">
													<br>
													<label>Νόμισμα:</label>
													<select name="currency" id="currency" class="form-control">
														<?php 
														echo"<option value='EUR'";
														if ($row['Currency']=="EUR")
															echo " selected='selected'";
														echo ">EUR</option>
														<option value='USD'";
														if ($row['Currency']=="USD")
															echo " selected='selected'";
														echo ">USD</option>
														<option value='GBP'";
														if ($row['Currency']=="GBP")
															echo " selected='selected'";
														echo ">GBP</option>
														<option value='RUS'";
														if ($row['Currency']=="RUS")
															echo " selected='selected'";
														echo ">RUS</option>";
														?>
													</select>
												</div>
											</div>
											<div class="col-md-6">
												<br>
												<label>ΦΠΑ (%)</label>
												<input type="text" class="form-control" name="vat" value="<?php echo $row['VAT']; ?>">
											</div>

											<div class="col-md-6">
												<br>
												<label>Τίτλος εγγραφής</label>
												<input type="text" class="form-control" name="RegistartionTitle" value="<?php echo $row['RegistrationTitle']; ?>">
											</div>
											<br>
											<label>Υπεύθυνος μεσίτης</label>
											<span runat="server" ID="required" style="color:Red;" visible="false"> *</span>
											<input type="text" class="form-control" required name="AgentUsername" value="<?php echo $row['AgentUsername']; ?>">

											<div class="col-md-6">
												<br>
												<label>Κωδικός Εντολής</label>
												<input type="text" class="form-control" name="OrderCode" value="<?php echo $row['OrderCode']; ?>">
											</div>
											<div class="col-md-6">
												<br>
												<label>Τύπος εντολής</label>
												<input type="text" class="form-control" name="TypeCode" value="<?php echo $row['TypeOrder']; ?>">
											</div>

											<div class="col-md-6">
												<br>
												<label>Έναρξη εντολής</label>
												<input type="text" class="form-control" name="OrderStart" value="<?php echo $row['OrderStart']; ?>">
											</div>
											<div class="col-md-6">
												<br>
												<label>Λήξη εντολής</label>
												<input type="text" class="form-control" name="OrderStop" value="<?php echo $row['OrderStop']; ?>">
											</div>

											<div class="col-md-6">
												<br>
												<label>Αμοιβή (%)</label>
												<input type="text" class="form-control" name="AgentRewardPercentage" value="<?php echo $row['AgentRewardPercentage']; ?>">
											</div>
											<div class="col-md-6">
												<br>
												<label>Αμοιβή (Ποσό)</label>
												<input type="text" class="form-control" name="AgentReward" value="<?php echo $row['AgentReward']; ?>">
												<br>
											</div>
											<br>
											<label>Διαθεσιμότητα από</label>
											<input type="text" class="form-control" name="AvailableFrom" value="<?php echo $row['AvailableFrom']; ?>">

											<div class="col-md-6">
												<br>
												<label>Κόστος μεταβίβασης</label>
												<input type="text" class="form-control" name="TransferCost" value="<?php echo $row['TransferCost']; ?>">
											</div>
											<div class="col-md-6">
												<br>
												<label>Φόρος Κόστους Μεταβίβασης (VAT)</label>
												<input type="text" class="form-control" name="TransferVAT" value="<?php echo $row['TransferVAT']; ?>">
												<br>
											</div>

											<br>
											<label>Ανέβασε φωτογραφίες</label>
											<input type="file" name="photo">
										</div><!--end of 1i stili-->

										<div class="col-md-6">
											<div class="col-md-6">
												<label>Αριθμός οδού</label>
												<span runat="server" ID="required" style="color:Red;" visible="false"> *</span>
												<input type="text" class="form-control" required name="astreet_no" value="<?php echo $row['AStreetNo']; ?>">
												<br>
											</div>
											<div class="col-md-6">
												<label>Τ.Κ.</label>
												<span runat="server" ID="required" style="color:Red;" visible="false"> *</span>
												<input type="text" class="form-control" required name="apostal_code" value="<?php echo $row['APostalCode']; ?>">
												<br>
											</div>

											<label>Xώρα</label>
											<span runat="server" ID="required" style="color:Red;" visible="false"> *</span>
											<input type="text" class="form-control" required name="acountry" value="<?php echo $row['ACountry']; ?>">

											<div class="col-md-6">
												<br>
												<label>Latitude</label>
												<span runat="server" ID="required" style="color:Red;" visible="false"> *</span>
												<input type="text" class="form-control" name="Latitude" value="<?php echo $row['Latitude']; ?>">
												<br>
											</div>
											<div class="col-md-6">
												<br>
												<label>Longitude</label>
												<span runat="server" ID="required" style="color:Red;" visible="false"> *</span>
												<input type="text" class="form-control" name="Longitude" value="<?php echo $row['Longitude']; ?>">
												<br>
											</div>

											<div class="form-group">
												<br>
												<label>Σκοπός εγγραφής ακινήτου:</label>
												<span runat="server" ID="required" style="color:Red;" visible="false"> *</span>
												<select name="purpose" id="purpose" class="form-control" required >
													<?php 
													echo "<option value='Πώληση'";
													if ($row['RegistrationPurpose']=="Πώληση")
														echo " selected='selected'";
													echo ">Πώληση</option>
													<option value='Ενοικίαση'";
													if ($row['RegistrationPurpose']=="Ενοικίαση")
														echo " selected='selected'";
													echo ">Ενοικίαση</option>
													<option value='Αντιπαροχή'";
													if ($row['RegistrationPurpose']=="Αντιπαροχή")
														echo " selected='selected'";
													echo ">Αντιπαροχή</option>
													<option value='Επένδυση'";
													if ($row['RegistrationPurpose']=="Επένδυση")
														echo " selected='selected'";
													echo ">Επένδυση</option>";
													?>
												</select>
											</div>
											<div class="col-md-6">
												<label>Αριθμός τεμαχίου:</label>
												<span runat="server" ID="required" style="color:Red;" visible="false"> *</span>
												<input type="text" required class="form-control" name="piece_no" value="<?php echo $row['PieceNo']; ?>">
												<br>
											</div>
											<div class="col-md-6">
												<label>Αριθμός φακέλου:</label>
												<input type="text" class="form-control" name="folder_no" value="<?php echo $row['FolderNo']; ?>">
												<br>
											</div>

											<br>
											<label>Αριθμός αδ. οικ.</label>
											<input type="text" class="form-control" name="ArithmosAdOik" value="<?php echo $row['ArithmosAdOik']; ?>">

											<div class="col-md-6">
												<br>
												<label>Τιμή</label>
												<span runat="server" ID="required" style="color:Red;" visible="false"> *</span>
												<input type="text" class="form-control" required name="price" value="<?php echo $row['Price']; ?>">
												<br>
											</div>
											<div class="col-md-6">
												<br>
												<label>Υποθήκη/Δάνειο</label>
												<span runat="server" ID="required" style="color:Red;" visible="false"> *</span>
												<select name="ipothiki" id="ipothiki" required class="form-control">
													<?php
													echo"<option value='1'";
													if ($row['MortgageLoan']=="1")
														echo " selected='selected'";
													echo ">Yes</option>
													<option value='0'";
													if ($row['MortgageLoan']=="0")
														echo " selected='selected'";
													echo ">No</option>";
													?>
												</select>
												<br>
											</div>
											<div class="form-group">
												<br>
												<label>Σύντομη Περιγραφή</label>
												<textarea class="form-control" name="short_desc" rows="3" value="<?php echo $row['ShortDescription']; ?>" id="message" data-validation-required-message="Please enter a message."></textarea>
											</div>
											<div class="form-group">
												<label>Αναλυτική Περιγραφή</label>
												<textarea class="form-control" name="desc" rows="6" value="<?php echo $row['Description']; ?>" id="message"  data-validation-required-message="Please enter a message."></textarea>
											</div>
											<div class="form-group">
												<label>Notes</label>
												<textarea class="form-control" name="notes" rows="5" value="<?php echo $row['Notes']; ?>" id="message"  data-validation-required-message="Please enter a message."></textarea>
											</div>
											<label>Αντιπαροχή/Ανταλλαγή</label>
											<span runat="server" ID="required" style="color:Red;" visible="false"> *</span>
											<select name="ConsiderationExchange" id="ConsiderationExchange" required class="form-control">
												<?php
												echo"<option value='1'";
												if ($row['ConsiderationExchange']=="1")
													echo " selected='selected'";
												echo ">Yes</option>
												<option value='0'";
												if ($row['ConsiderationExchange']=="0")
													echo " selected='selected'";
												echo ">No</option>";
												?>
												<br>
											</select>
										</div>
										<br>
										<br>
										<br>

										<div style="float:right;">
											<br>
											<button type="submit" name="next" class="btn btn-success">
												Επόμενο: Λεπτομέρειες και Χαρακτηριστικά
											</button>
										</div>
									</div>
								</form>
								<!-- End of first "tab" -->

							</div>
							<!-- /.main wrap -->
						</div>
						<!-- /. End of section : TABS (content) -->

					</div>
					<!-- /.row -->

				</div>
				<!-- /.container-fluid -->

			</div>
			<!-- /#page-wrapper -->

		</div>
		<!-- /#wrapper -->

		<!-- jQuery -->
		<script src="js/jquery.js"></script>

		<!-- Bootstrap Core JavaScript -->
		<script src="js/bootstrap.min.js"></script>

	</body>

	</html>