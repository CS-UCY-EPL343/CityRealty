<?php
ini_set('error_reporting', E_ALL);
ini_set('display_errors', 1);
session_start();

$conn = mysqli_connect("localhost", "CityRealty", "QKSH7XJws7MCpxWR", "CityRealty");
mysqli_query($conn,"SET NAMES utf8");

if (!$conn) {
	die("Connection failed: " . mysqli_connect_error());
}
if(isset($_POST['send']))
{
	$category = $_GET['category'];
	$reid = $_GET['reid'];

	if ($category=="Γη") {

		/*gi-land*/
		$LandType= $_POST['LandType'];
		$TMLand= $_POST['TMLand'];
		$TMBuilding= $_POST['TMBuilding'];
		$Builded= $_POST['Builded'];
		$NotBuilded= $_POST['NotBuilded'];
		$CityPlan= $_POST['CityPlan'];
		$InvestmentField= $_POST['InvestmentField'];
		$BuildIn= $_POST['BuildIn'];
		$SD= $_POST['SD'];
		$SK= $_POST['SK'];
		$Front= $_POST['Front'];
		$Depth= $_POST['Depth'];
		$AOT= $_POST['AOT'];
		$NumOfPlots= $_POST['NumOfPlots'];

		$sql1 = "UPDATE Land SET RealEstateNo='$reid',LandType='$LandType',TMLand='$LandType',TMBuilding='$TMBuilding',Builded='$Builded',NotBuilded='$NotBuilded',CityPlan='$CityPlan',InvestmentField='$InvestmentField',BuildIn='$BuildIn',SD='$SD',SK='$SK',Front='$Front',Depth='$Depth',AOT='$AOT',NumOfPlots='$NumOfPlots' WHERE RealEstateNo=$reid";
	}

	if ($category=="Κατοικία") {
		/*katoikia-Residence*/
		$ResidenceType= $_POST['ResidenceType'];
		//echo $ResidenceType;
		$Kitchen= $_POST['Kitchen'];
		$Bathrooms= $_POST['Bathrooms'];
		$RooftopArea= $_POST['RooftopArea'];
		$TotalBedrooms= $_POST['TotalBedrooms'];
		$MasterBedroom= $_POST['MasterBedroom'];
		$LivingRooms= $_POST['LivingRooms'];
		$BalconyArea= $_POST['BalconyArea'];
		$Furnished= $_POST['Furnished'];

		$sql2 = "UPDATE Residence SET RealEstateNo='$reid',ResidenceType='$ResidenceType',Kitchen='$Kitchen',Bathrooms='$Bathrooms',RooftopArea='$RooftopArea',TotalBedrooms='$TotalBedrooms',MasterBedroom='$MasterBedroom',LivingRooms='$LivingRooms',BalconyArea='$BalconyArea',Furnished='$Furnished' WHERE RealEstateNo=$reid";
	}

	if ($category=="Επαγγελματικός χώρος") {
		/*epaggelmatikos xwros-office*/
		$OfficeType= $_POST['OfficeType'];
		$NumOfBasements= $_POST['NumOfBasements'];
		$NumOfFloors= $_POST['NumOfFloors'];
		$StoreFrontArea= $_POST['StoreFrontArea'];
		$GroundFloorArea= $_POST['GroundFloorArea'];
		$EquipmentIncluded= $_POST['EquipmentIncluded'];
		$Investment= $_POST['Investment'];
		$NumOfSegments= $_POST['NumOfSegments'];
		$SurfaceArea= $_POST['SurfaceArea'];
		$LoftArea= $_POST['LoftArea'];
		$BasementArea= $_POST['BasementArea'];
		$AirPrice= $_POST['AirPrice'];

		$sql3 = "UPDATE Office SET RealEstateNo='$reid',OfficeType='$OfficeType',NumOfBasements='$NumOfBasements',NumOfFloors='$NumOfFloors',StoreFrontArea='$StoreFrontArea',GroundFloorArea='$GroundFloorArea',EquipmentIncluded='$EquipmentIncluded',Investment='$Investment',NumOfSegments='$NumOfSegments',SurfaceArea='$SurfaceArea',LoftArea='$LoftArea',BasementArea='$BasementArea',AirPrice='$AirPrice' WHERE RealEstateNo=$reid";
	}

	if (($category=="Ξενοδοχείο") || ($category=="Κατοικία") || ($category=="Επαγγελματικός χώρος")) {
		/*ksenodoxeio-building*/
		$BuildingType= $_POST['BuildingType'];
		$ConstructionYear= $_POST['ConstructionYear'];
		$NumOfFloorsB= $_POST['NumOfFloorsB'];
		$ParkingSpots= $_POST['ParkingSpots'];
		$NumOfRooms= $_POST['NumOfRooms'];
		$EnergyCertificate= $_POST['EnergyCertificate'];
		$Levels= $_POST['Levels'];
		$Renovated= $_POST['Renovated'];
		$RenovationYear= $_POST['RenovationYear'];
		$NumOfWC= $_POST['NumOfWC'];
		$Drainage= $_POST['Drainage'];
		$HeatingFuel= $_POST['HeatingFuel'];
		$HeatingType= $_POST['HeatingType'];
		$AvgSharedCosts= $_POST['AvgSharedCosts'];
		$UnderConstruction= $_POST['UnderConstruction'];

		$sql4 = "UPDATE Building SET RealEstateNo=$reid,BuildingType='$BuildingType',ConstructionYear='$ConstructionYear',NumOfFloors='$NumOfFloorsB',ParkingSpots='$ParkingSpots',NumOfRooms='$NumOfRooms',EnergyCertificate='$EnergyCertificate',Levels='$Levels',Renovated='$Renovated',RenovationYear='$RenovationYear',NumOfWC='$NumOfWC',Drainage='$Drainage',HeatingFuel='$HeatingFuel',HeatingType='$HeatingType',AvgSharedCosts='$AvgSharedCosts',UnderConstruction='$UnderConstruction' WHERE RealEstateNo=$reid";
	}

	if (isset($sql1)) {
		$result1 = mysqli_query($conn,$sql1)
		or die("Error: !".mysqli_error($conn));
	}
	if (isset($sql2)) {
		$result2 = mysqli_query($conn,$sql2)
		or die("Error: !".mysqli_error($conn));
	}
	if (isset($sql3)) {
		$result3 = mysqli_query($conn,$sql3)	
		or die("Error: !".mysqli_error($conn));
	}
	if (isset($sql4)) {
		$result4 = mysqli_query($conn,$sql4)	
		or die("Error: !".mysqli_error($conn));
	}

	$_SESSION['updatedProperty'] = "You've successfully updated the property!";
	$id = $_SESSION['id'];
	$sql2 = "SELECT UserType FROM UserSimple WHERE Username='$id'";
	$result2 = mysqli_query($conn,$sql2);
	$row2=mysqli_fetch_assoc($result2);
	if ($row2['UserType']=="Admin") {
		mysqli_close($conn);
		header("Location: admin.php");
	} else {
		mysqli_close($conn);
		header("Location: broker_manage.php");
	}
}
?>



